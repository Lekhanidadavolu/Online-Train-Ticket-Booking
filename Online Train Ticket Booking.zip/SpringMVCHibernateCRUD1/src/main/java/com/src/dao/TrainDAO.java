package com.src.dao;

import java.util.List;

import com.src.model.Train;

public interface TrainDAO {

	public void addTrain(Train t);
	public void updateTrain(Train t);
	public List<Train> listTrains();
	public Train getTrainByTrainno(int trainno);
	public void removeTrain(int trainno);
}
