package com.src.dao;

import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.src.model.Train;


@Repository
public class TrainDAOImpl implements TrainDAO{

    @Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	@Override
	public void addTrain(Train t) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(t);
		//logger.info("Train saved successfully, Train Details="+t);
	}

	@Override
	public void updateTrain(Train t) {
		Session session = this.sessionFactory.getCurrentSession();
		session.update(t);
	//	logger.info("Train updated successfully, Train Details="+t);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Train> listTrains() {
		Session session = this.sessionFactory.getCurrentSession();
		List<Train> trainsList = session.createQuery("from Train").list();
		for(Train t : trainsList){
		//	logger.info("Train List::"+t);
		}
		return trainsList;
	}

	@Override
	public Train getTrainByTrainno(int trainno) {
		Session session = this.sessionFactory.getCurrentSession();		
		Train t = (Train) session.load(Train.class, new Integer(trainno));
		//logger.info("Train loaded successfully, Train details="+t);
		return t;
	}

	@Override
	public void removeTrain(int trainno) {
		Session session = this.sessionFactory.getCurrentSession();
		Train t = (Train) session.load(Train.class, new Integer(trainno));
		if(null != t){
			session.delete(t);
		}
		//logger.info("Train deleted successfully, Train details="+t);
	}
	
}
