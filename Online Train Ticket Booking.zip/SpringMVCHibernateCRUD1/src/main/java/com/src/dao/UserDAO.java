package com.src.dao;

import com.src.model.User;

public interface UserDAO {

	public boolean validate1(User user);
}
