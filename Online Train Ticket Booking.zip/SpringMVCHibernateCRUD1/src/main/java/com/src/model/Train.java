package com.src.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TRAIN")
public class Train {

	@Id
	@Column(name="Source")
	private String Source;
	private String Destination;
	
	private int Trainno;
	
	private String Trainname;
	
	private String slot;

	

	public String getSource() {
		return Source;
	}



	public void setSource(String source) {
		Source = source;
	}



	public String getDestination() {
		return Destination;
	}



	public void setDestination(String destination) {
		Destination = destination;
	}



	public int getTrainno() {
		return Trainno;
	}



	public void setTrainno(int trainno) {
		Trainno = trainno;
	}



	public String getTrainname() {
		return Trainname;
	}



	public void setTrainname(String trainname) {
		Trainname = trainname;
	}



	public String getSlot() {
		return slot;
	}



	public void setSlot(String slot) {
		this.slot = slot;
	}



	@Override
	public String toString() {
		return "Train [Source=" + Source + ", Destination=" + Destination + ", Trainno=" + Trainno + ", Trainname="
				+ Trainname + ", slot=" + slot + "]";
	}

	


	
}
