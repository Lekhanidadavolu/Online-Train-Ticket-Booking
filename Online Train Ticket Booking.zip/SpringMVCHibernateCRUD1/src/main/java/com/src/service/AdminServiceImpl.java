package com.src.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.AdminDAO;

import com.src.model.Admin;

@Service
@Transactional
public class AdminServiceImpl implements AdminServiceI {

	@Autowired
	private AdminDAO adminDAO;
	
	@Override
	public boolean validate(Admin admin) {
		
		return adminDAO.validate(admin);
	}

	@Override
	public List<Admin> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object find(String sourceStation, String destinationStation, int day, String trainType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateTrain(Admin train) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void create(Object train) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object listTrains() {
		// TODO Auto-generated method stub
		return null;
	}

}
