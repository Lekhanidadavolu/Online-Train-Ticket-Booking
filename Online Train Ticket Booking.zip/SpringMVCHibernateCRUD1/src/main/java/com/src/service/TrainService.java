package com.src.service;

import java.util.List;

import com.src.model.Train;

public interface TrainService {

	public void addTrain(Train t);
	public void updateTrain(Train t);
	public List<Train> listTrains();
	public Train getTrainByTrainno(int trainno);
	public void removeTrain(int trainno);
	public void create(Train train);
	public List<Train> findAll();
	public Object find(String sourceStation, String destinationStation, int day, String trainType);


}
