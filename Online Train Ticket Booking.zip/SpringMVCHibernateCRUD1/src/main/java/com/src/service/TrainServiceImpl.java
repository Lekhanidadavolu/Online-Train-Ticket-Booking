package com.src.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.src.dao.TrainDAO;
import com.src.model.Train;

@Service
public class TrainServiceImpl implements TrainService{
    @Autowired
	private TrainDAO trainDAO;

	public void setTrainDAO(TrainDAO trainDAO) {
		this.trainDAO = trainDAO;
	}

	@Override
	@Transactional
	public void addTrain(Train t) {
		this.trainDAO.addTrain(t);
	}

	@Override
	@Transactional
	public void updateTrain(Train t) {
		this.trainDAO.updateTrain(t);
	}

	@Override
	@Transactional
	public List<Train> listTrains() {
		return this.trainDAO.listTrains();
	}

	@Override
	@Transactional
	public Train getTrainByTrainno(int trainno) {
		return this.trainDAO.getTrainByTrainno(trainno);
	}

	@Override
	@Transactional
	public void removeTrain(int trainno) {
		this.trainDAO.removeTrain(trainno);
		Train train = null;
		this.trainDAO.addTrain(train);

	}

	@Override
	@Transactional

	public void create(Train train) {
		// TODO Auto-generated method stub
		this.trainDAO.addTrain(train);
	}

	@Override
	public List<Train> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object find(String sourceStation, String destinationStation, int day, String trainType) {
		// TODO Auto-generated method stub
		return null;
	}
}
