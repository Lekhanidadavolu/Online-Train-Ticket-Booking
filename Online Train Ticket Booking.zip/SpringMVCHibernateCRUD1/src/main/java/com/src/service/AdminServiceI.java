package com.src.service;

import java.util.List;

import com.src.model.Admin;

public interface AdminServiceI {

	
	public boolean validate(Admin ad);

	public List<Admin> findAll();

	public Object find(String sourceStation, String destinationStation, int day, String trainType);

	public void updateTrain(Admin train);

	public void create(Object train);

	public Object listTrains();

	
	
}
