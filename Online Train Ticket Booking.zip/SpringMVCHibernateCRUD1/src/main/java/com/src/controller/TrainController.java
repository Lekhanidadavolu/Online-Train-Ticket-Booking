package com.src.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.src.model.Train;
import com.src.service.TrainService;



@Controller
public class TrainController {
	private static final Logger logger = Logger
			.getLogger(UserController.class);

	public TrainController() {
		System.out.println("TrainController()");
	}
	@Autowired
	private TrainService trainService;
	
	
	@RequestMapping(value="/addtrain",method=RequestMethod.POST )
	public String addTrain1(@ModelAttribute("train") Train train,ModelAndView model)
	{
		
		trainService.create(train);
		return "redirect:/trains";
	}
	
	@RequestMapping(value="/displaytrainlist",method=RequestMethod.POST )
	public String display()
	{
		
		return "displaytrainlist";
	}
	
	
	@RequestMapping(value="/Booknow",method=RequestMethod.GET )
	public String book()
	{
		
		return "Booknow";
	}
	
	
	@RequestMapping(value="/passengerdetails",method=RequestMethod.GET )
	public String passengerdisplay()
	{
		
		return "passengerdetails";
	}
	
//	@RequestMapping(value="/gettrains")
//	public @ResponseBody List<Train> getTrains()
//	{
//		
//		return trainService.findAll();
//	}
	
//	@RequestMapping(value="/updateTrain",method=RequestMethod.POST )
//	public Map<String,Object>updateTrain(@RequestBody Train train)
//	{
//		Map<String,Object> response =new HashMap<String, Object>();
//		try {
//		trainService.updateTrain(train);
//		response.put("message","Train updated successfully!");
//		}
//		catch(Exception e) {
//			response.put("message", "Update error"+e.toString());
//		}
//		
//		response.put("train", train);
//		return response;
//	}
//	
//	@RequestMapping(value="/getsearchdetails", method=RequestMethod.GET)
//	public Map<String,Object> getsearchdetails(@RequestParam("sourceStation") String sourceStation,
//			@RequestParam("destinationStation") String destinationStation,
//			
//			@RequestParam("trainType") String trainType,
//			@RequestParam("day") int day){
//		Map<String,Object> response =new HashMap<String, Object>();
//		try {
//		
//		response.put("message","Search successful!");
//		response.put("list", trainService.find(sourceStation, destinationStation, day, trainType));
//		}
//		catch(Exception e) {
//			response.put("message", "Error"+e.toString());
//		}
//		
//		
//		return response;
//		
//			
//		
//	}
//	
//
	@RequestMapping(value = "/trains", method = RequestMethod.GET)
	public String listTrains(Model model) {
		model.addAttribute("train", new Train());
		model.addAttribute("listTrains", this.trainService.listTrains());
		return "train";
	}
	
}
